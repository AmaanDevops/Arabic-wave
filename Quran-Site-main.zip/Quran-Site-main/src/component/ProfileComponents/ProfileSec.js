// import React, { useState } from 'react';

// export default function Profiley() {
//     return(
//         <>
//                 <div className='profile'>
//                     <h1>Your Profile</h1>
//                     <p>
//                         Here you can change your profile details just as you want but becarfull so you don't forget your own details
//                     </p>
//                     <div className="form-container ">
//                         <form action="" >
//                             <div>
//                                 <div className="input-container">
//                                     <input placeholder='SubWay74' type="text"/>
//                                     <label className="transition">User name</label>
//                                     <p>newpassword</p>
//                                 </div>
//                                 <div className="input-container">
//                                     <input placeholder='sub74741@gmail.com' type="email"/>
//                                     <label className="transition">Email</label>
//                                     <p>newpassword</p>
//                                 </div>
//                                 <div className="input-container">
//                                     <input placeholder='*********' type="password"/>
//                                     <label className="transition">Password</label>
//                                     <p>newpassword</p>
//                                 </div>
//                             </div>
//                             <button className="btn center">Change</button>
//                         </form>
//                     </div>
//                 </div>
//         </>
//     )
// }